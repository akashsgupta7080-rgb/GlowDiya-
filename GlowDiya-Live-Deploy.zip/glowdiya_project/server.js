const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Pool } = require('pg');

const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
const ADMIN_TOKEN_TTL_MS = 12 * 60 * 60 * 1000;
const HTML_FILE = path.join(__dirname, 'GlowDiya_FINAL-2-admin.html');
const sessions = new Map();

if (!process.env.DATABASE_URL) {
  console.error('DATABASE_URL is required.');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 5,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : undefined
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS admin_account (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      salt TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      created_at TIMESTAMPTZ NOT NULL,
      updated_at TIMESTAMPTZ,
      customer JSONB NOT NULL,
      delivery TEXT NOT NULL,
      payment TEXT NOT NULL,
      payment_status TEXT NOT NULL,
      status TEXT NOT NULL,
      items JSONB NOT NULL,
      total NUMERIC(12,2) NOT NULL
    );
    CREATE INDEX IF NOT EXISTS orders_created_at_idx ON orders(created_at DESC);
  `);
}

function send(res, status, body, extraHeaders = {}) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...extraHeaders
  });
  res.end(payload);
}

function serveHtml(res) {
  if (!fs.existsSync(HTML_FILE)) return send(res, 500, { error: 'Storefront file missing.' });
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  fs.createReadStream(HTML_FILE).pipe(res);
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 1e6) {
        req.destroy();
        reject(new Error('Request too large'));
      }
    });
    req.on('end', () => {
      try { resolve(raw ? JSON.parse(raw) : {}); }
      catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  return { salt, hash: crypto.scryptSync(password, salt, 64).toString('hex') };
}
function verifyPassword(password, record) {
  const derived = crypto.scryptSync(password, record.salt, 64);
  const expected = Buffer.from(record.hash, 'hex');
  return expected.length === derived.length && crypto.timingSafeEqual(expected, derived);
}

function auth(req) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  const session = sessions.get(token);
  if (!session || session.expiresAt < Date.now()) {
    if (session) sessions.delete(token);
    return null;
  }
  session.expiresAt = Date.now() + ADMIN_TOKEN_TTL_MS;
  return { token, session };
}

function validateOrder(o) {
  if (!o?.customer?.name || !o.customer.phone || !o.customer.address || !o.customer.pincode) return 'Customer details are required.';
  if (!/^\d{10}$/.test(String(o.customer.phone))) return 'Invalid mobile number.';
  if (!/^\d{6}$/.test(String(o.customer.pincode))) return 'Invalid pincode.';
  if (!Array.isArray(o.items) || !o.items.length) return 'Order items are required.';
  if (!Number.isFinite(Number(o.total)) || Number(o.total) < 0) return 'Invalid order total.';
  return null;
}

function rowToOrder(r) {
  return {
    id: r.id,
    createdAt: new Date(r.created_at).toISOString(),
    updatedAt: r.updated_at ? new Date(r.updated_at).toISOString() : undefined,
    customer: r.customer,
    delivery: r.delivery,
    payment: r.payment,
    paymentStatus: r.payment_status,
    status: r.status,
    items: r.items,
    total: Number(r.total)
  };
}

function loginResponse(res) {
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = Date.now() + ADMIN_TOKEN_TTL_MS;
  sessions.set(token, { expiresAt });
  return send(res, 200, { token, expiresAt });
}

const server = http.createServer(async (req, res) => {
  try {
    if (req.method === 'OPTIONS') {
      res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Allow-Methods': 'GET, POST, PATCH, DELETE, OPTIONS' });
      return res.end();
    }

    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const p = url.pathname;

    if (req.method === 'GET' && (p === '/' || p === '/index.html')) return serveHtml(res);
    if (req.method === 'GET' && p === '/api/health') {
      const r = await pool.query('SELECT EXISTS (SELECT 1 FROM admin_account WHERE id = 1) AS configured');
      return send(res, 200, { ok: true, adminConfigured: r.rows[0].configured });
    }

    if (req.method === 'POST' && p === '/api/admin/setup') {
      const existing = await pool.query('SELECT id FROM admin_account WHERE id = 1');
      if (existing.rowCount) return send(res, 409, { error: 'Admin is already configured.' });
      const { password } = await parseBody(req);
      if (typeof password !== 'string' || password.length < 8) return send(res, 400, { error: 'Password must be at least 8 characters.' });
      const { salt, hash } = hashPassword(password);
      await pool.query('INSERT INTO admin_account (id, salt, password_hash) VALUES (1, $1, $2)', [salt, hash]);
      return loginResponse(res);
    }

    if (req.method === 'POST' && p === '/api/admin/login') {
      const r = await pool.query('SELECT salt, password_hash AS hash FROM admin_account WHERE id = 1');
      if (!r.rowCount) return send(res, 404, { error: 'Admin is not configured yet.' });
      const { password } = await parseBody(req);
      if (typeof password !== 'string' || !verifyPassword(password, r.rows[0])) return send(res, 401, { error: 'Incorrect admin password.' });
      return loginResponse(res);
    }

    if (req.method === 'POST' && p === '/api/admin/logout') {
      const a = auth(req);
      if (a) sessions.delete(a.token);
      return send(res, 200, { ok: true });
    }

    if (req.method === 'POST' && p === '/api/orders') {
      const order = await parseBody(req);
      const err = validateOrder(order);
      if (err) return send(res, 400, { error: err });
      const clean = {
        id: String(order.id || ('GD-' + Date.now().toString().slice(-8))),
        createdAt: order.createdAt || new Date().toISOString(),
        customer: { name: String(order.customer.name), phone: String(order.customer.phone), address: String(order.customer.address), pincode: String(order.customer.pincode) },
        delivery: String(order.delivery || 'Standard Delivery'),
        payment: String(order.payment || 'COD'),
        paymentStatus: String(order.paymentStatus || (order.payment === 'COD' ? 'Pending' : 'Paid')),
        status: 'New Order',
        items: order.items.map(i => ({ n: String(i.n || 'Product'), p: Number(i.p) || 0 })),
        total: Number(order.total)
      };
      await pool.query(
        `INSERT INTO orders (id, created_at, customer, delivery, payment, payment_status, status, items, total)
         VALUES ($1, $2, $3::jsonb, $4, $5, $6, $7, $8::jsonb, $9)`,
        [clean.id, clean.createdAt, JSON.stringify(clean.customer), clean.delivery, clean.payment, clean.paymentStatus, clean.status, JSON.stringify(clean.items), clean.total]
      );
      return send(res, 201, { order: clean });
    }

    if (req.method === 'GET' && p === '/api/orders') {
      if (!auth(req)) return send(res, 401, { error: 'Unauthorized' });
      const r = await pool.query('SELECT * FROM orders ORDER BY created_at DESC');
      return send(res, 200, { orders: r.rows.map(rowToOrder) });
    }

    const match = p.match(/^\/api\/orders\/([^/]+)$/);
    if (match && req.method === 'PATCH') {
      if (!auth(req)) return send(res, 401, { error: 'Unauthorized' });
      const id = decodeURIComponent(match[1]);
      const patch = await parseBody(req);
      const allowedStatus = ['New Order', 'Packaging', 'Shipping', 'Delivered', 'Cancelled'];
      const allowedPayment = ['Pending', 'Paid', 'Failed', 'Refunded'];
      if (patch.status && !allowedStatus.includes(patch.status)) return send(res, 400, { error: 'Invalid order status.' });
      if (patch.paymentStatus && !allowedPayment.includes(patch.paymentStatus)) return send(res, 400, { error: 'Invalid payment status.' });
      const r = await pool.query(
        `UPDATE orders SET status = COALESCE($2, status), payment_status = COALESCE($3, payment_status), updated_at = NOW()
         WHERE id = $1 RETURNING *`,
        [id, patch.status || null, patch.paymentStatus || null]
      );
      if (!r.rowCount) return send(res, 404, { error: 'Order not found.' });
      return send(res, 200, { order: rowToOrder(r.rows[0]) });
    }

    if (req.method === 'DELETE' && p === '/api/orders') {
      if (!auth(req)) return send(res, 401, { error: 'Unauthorized' });
      await pool.query('DELETE FROM orders');
      return send(res, 200, { ok: true });
    }

    return send(res, 404, { error: 'Not found' });
  } catch (e) {
    console.error(e);
    return send(res, 500, { error: 'Server error.' });
  }
});

(async () => {
  await initDb();
  server.listen(PORT, HOST, () => console.log(`GlowDiya running on port ${PORT}`));
})().catch(err => {
  console.error('Startup failed:', err);
  process.exit(1);
});
