# GlowDiya — live deployment

This build serves the customer storefront and admin panel from the same Node.js service and stores orders/admin credentials in PostgreSQL.

## Deploy on Render
1. Put this folder in a GitHub repository.
2. In Render, choose **New → Blueprint** and connect the repository.
3. Render will read `render.yaml` and create the web service + PostgreSQL database.
4. Wait for the deploy to finish. Open the generated `https://*.onrender.com` URL.
5. The first time you tap **Admin**, create the admin password.
6. Place a test customer order. It should appear in Admin.

The current Blueprint uses Render's Free plans for testing. Render says Free web services can spin down after 15 minutes of inactivity, and Free Postgres expires after 30 days. For a real store, upgrade the database/service before relying on it for production data.

## Local run
Set DATABASE_URL to a PostgreSQL database, then:

    npm install
    npm start

Open http://localhost:3000
